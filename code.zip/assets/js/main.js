window.onload = function () {
  myCart = JSON.parse(window.localStorage.getItem('myCart'))
  console.log(myCart);
  if (myCart) {
    showNoti(myCart);
  }
}


